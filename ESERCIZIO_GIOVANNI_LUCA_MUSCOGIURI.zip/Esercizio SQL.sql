/*Creazione Schema e Tabelle */

Create schema ToysGroup
;

use ToysGroup
;

CREATE TABLE Products (
    product_id INT PRIMARY KEY,
    product_name VARCHAR(100),
    category VARCHAR(50),
    price DECIMAL(10,2)
);

CREATE TABLE Regions (
    region_id INT PRIMARY KEY,
    region_name VARCHAR(100),
    country VARCHAR(50)
);

CREATE TABLE Sales (
    sale_id INT PRIMARY KEY,
    product_id INT,
    region_id INT,
    sale_date DATE,
    quantity INT,
    FOREIGN KEY (product_id) REFERENCES Products(product_id),
    FOREIGN KEY (region_id) REFERENCES Regions(region_id)
);

/* Popolo le tabelle con dati */

INSERT INTO Products (product_id, product_name, category, price)
VALUES
  (1, 'Barbie', 'Bambole', 19.99),
  (2, 'Costruzioni Lego', 'Costruzioni', 39.99),
  (3, 'Pongo', 'Dido', 9.99),
  (4, 'Console Videogiochi', 'Videogiochi', 499.99),
  (5, 'Set di Libri per Bambini', 'Libri', 24.99),
  (6, 'Puzzle Lego', 'Puzzle', 49.99)
  ;
  
INSERT INTO Regions (region_id, region_name, country)
VALUES
  (1, 'Nord America Est', 'USA'),
  (2, 'Nord America Ovest', 'USA'),
  (3, 'Europe', 'Italia'),
  (4, 'Asia', 'Cina'),
  (5, 'Sud America', 'Brasile')
  ;
  
INSERT INTO Sales (sale_id, product_id, region_id, sale_date, quantity)
VALUES
  (1, 1, 1, '2023-05-15', 2),
  (2, 1, 2, '2023-06-13', 3),
  (3, 1, 2, '2023-06-17', 4),
  (4, 3, 2, '2023-07-19', 1),
  (5, 3, 2, '2023-09-17', 10),
  (6, 3, 2, '2023-11-19', 8),
  (7, 2, 2, '2023-12-25', 1),
  (8, 3, 3, '2024-01-10', 4),
  (9, 4, 4, '2024-02-15', 3),
  (10, 5, 5, '2024-03-20', 5),
  (11, 2, 3, '2024-04-15', 2),
  (12, 3, 4, '2024-05-21', 4),
  (13, 4, 4, '2024-05-23', 5),
  (14, 3, 2, '2024-06-02', 5)
  ;
  
/* Verificare che i campi definiti come PK siano univoci. */

/* Tabella products */

SELECT 
	COUNT(*) AS totale_righe,
	COUNT(product_id) AS totale_ID
    
FROM 
Products
;

/* Tabella regions */

SELECT 
	COUNT(*) AS totale_righe, 
	COUNT(region_id) AS totale_ID
    
FROM 
Regions
;

/* Tabella sales */

SELECT 
	COUNT(*) AS totale_righe, 
	COUNT(sale_id) AS totale_ID
FROM 
Sales
;

/* Esporre l’elenco dei soli prodotti venduti e per ognuno di questi
 il fatturato totale per anno. */

SELECT 
	p.product_name as Nome_Prodotto, 
	YEAR(s.sale_date) AS Anno, 
	SUM(p.price * s.quantity) AS Fatturato_per_anno

FROM 
	Products p
	INNER JOIN Sales s ON p.product_id = s.product_id
GROUP BY p.product_name, YEAR(s.sale_date)
;

/* Esporre il fatturato totale per stato per anno.
Ordina il risultato per data e per fatturato decrescente. */

SELECT 
r.region_name as Regione,
YEAR(s.sale_date) AS Anno,
SUM(p.price * s.quantity) AS Fatturato_per_anno
 
FROM 
	Regions r
	INNER JOIN Sales s ON r.region_id = s.region_id
	INNER JOIN Products p ON s.product_id = p.product_id
GROUP BY r.region_name, YEAR(s.sale_date)
ORDER BY Anno, Fatturato_per_anno DESC
;

/* qual è la categoria di articoli maggiormente richiesta dal mercato? */

SELECT 
	p.category, 
	SUM(s.quantity) AS Totale_Quantità
FROM 
	Products p
	INNER JOIN Sales s ON p.product_id = s.product_id
GROUP BY p.category
ORDER BY Totale_Quantità DESC
LIMIT 1
;

/*quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti. */

-- Approccio con subquery

SELECT 
	product_name
FROM 
	Products
WHERE 
	product_id NOT IN (
	  SELECT product_id
	  FROM Sales
)
;

-- Approccio con Left Join

SELECT
	p.product_name
FROM 
	Products p
	LEFT JOIN Sales s ON p.product_id = s.product_id
WHERE s.sale_id IS NULL
;

/* Esporre l’elenco dei prodotti con la rispettiva ultima data di vendita
 (la data di vendita più recente) */
 
SELECT 
	p.product_name as Nome_Prodotto, 
	MAX(s.sale_date) AS Ultima_data_vendita
FROM 
	Products p
	INNER JOIN Sales s ON p.product_id = s.product_id
GROUP BY p.product_name
;